# Publish: "Choosing an Ethical Collection Agency" (SWRS guide)

Approval: Steven Dietz is the sole approval authority. Do not publish until he says go.
Nothing in this package changes any existing page. One new page only.

## 1. Files
| File | What it is |
|---|---|
| `wordpress-page-content.html` | The page body. Paste into ONE Custom HTML block. Content only: no header, footer, head or H1. CSS is scoped under `.swrs-guide` so it cannot affect the theme. |
| Video (download links, not in this ZIP because of size) | **1080p file to use on the page (33 MB):** https://stevendietz.github.io/swrs-intent-decks/video/swrs-ya-we-dont-do-that-1080p.mp4  |
|  | **Poster image (also in this ZIP under video/):** https://stevendietz.github.io/swrs-intent-decks/video/swrs-ya-we-dont-do-that-poster.jpg  |
| `linking-strategy.md` | Verified outbound links, inbound link plan, anchor rules. |
| `ALTERNATIVE-standalone-landing-page.html` | Full standalone page (own header/footer) for use on a landing subdomain instead. Not needed for the WordPress route. |

## 2. Create the page
- Pages > Add New.
  - **Page title (becomes the H1 in the theme masthead):** Why Collection Agencies Have a Bad Reputation, and How to Choose an Ethical One
- Slug: `choosing-an-ethical-collection-agency` under Resources, so the URL is `https://www.swrecovery.com/resources/choosing-an-ethical-collection-agency/`
  (If Resources pages are children of the Resources page, set that as the parent. Steven to confirm the URL before publish.)
- Add one Custom HTML block, paste the full contents of `wordpress-page-content.html`. Do not add a second H1. Do not split the file across blocks.

## 3. Video (do this before publishing)
- Right-click > Save the 1080p file from the link in the table above, then upload it and the poster JPG to the Media Library.
- In the pasted HTML, replace the three GitHub Pages URLs
  (`https://stevendietz.github.io/swrs-intent-decks/video/...`) with the Media Library URLs: the `<video poster>`, the `<source src>`, and the two `contentUrl` / `thumbnailUrl` values in the VideoObject JSON-LD at the top.
- Reason: the video must live on the swrecovery.com domain for the page to get the full SEO and reliability benefit. The GitHub copy works as a fallback.
- Do NOT replace it with a YouTube embed: YouTube auto-suggests other companies' videos after playback.

## 4. Rank Math (Edit with Rank Math > General / Schema)
- SEO title: `Choosing an Ethical Collection Agency: 10 Questions to Ask` (58 characters)
- Meta description: `Why collection agencies have a bad reputation, plus ten questions to ask and eight red flags to spot before you hire one to work your customers.` (144 characters)
- Focus keyword: `ethical debt collection agency` (Ahrefs US volume 70). Secondary terms are unverified; do not add keyword-stuffing.
- Robots: index, follow. Canonical: self (the URL above).
- Schema type: **Article**. Author: set the post author to the Southwest Recovery Services user (it should not show an individual's name).
- Social image: the poster JPG.
- Breadcrumb: Home > Resources > this page.

## 5. Schema: avoid duplicates
- FAQPage: do NOT add it manually and do NOT use the Rank Math FAQ block. The SWR FAQ Injector v2 builds FAQPage JSON-LD automatically from the nine `details.swrs-faq-card` items in the page. Confirm exactly one FAQPage after publish.
- VideoObject: already inline at the top of the pasted HTML. Keep it (update the URLs per step 3).
- Article, WebPage, Breadcrumb: Rank Math only. Do not add them to the HTML.

## 6. Before you hit publish: QA checklist
- [ ] Page renders on desktop and phone: no sideways scroll, comparison table scrolls inside its own box.
- [ ] Video plays, shows the poster first, and nothing else autoplays or is suggested afterward.
- [ ] The nine FAQ items open and close.
- [ ] All links open: the outbound source links, the Request-a-Quote button, the five internal links.
- [ ] Exactly one H1 on the page (the masthead).
- [ ] Google Rich Results Test: Article + VideoObject + FAQPage detected, no errors.
- [ ] View source: one FAQPage block only.
- [ ] Verify with a full Chrome user agent (the WAF returns 406 to default agents).

## 7. After publish (within 7 days)
- Add the inbound links listed in `linking-strategy.md`.
- Submit the URL in Search Console. Add it to the page sitemap if it is not auto-added.
- Watch Search Console for 30 days: this page overlaps the existing post
  `/resources/blog/how-to-hire-a-collection-agency-tips-for-businesses`. If both rank for the same queries and compete, tell Steven before making any change.

## 8. Do not
- Do not edit the wording of the statute and source claims in the "Sources" and "reputation" sections. They are compliance-sensitive.
- Do not add SWRS capability, credential, license or statistic claims to the page. It deliberately says only what Steven has stated or a source supports.
- Do not stack other site changes into the same deploy.

## 9. Open items for Steven (not blockers for the WordPress team, but needed before go-live)
1. Confirm the final URL and slug.
2. The site says "seven states" in some places and "six states" in others. This page says **eight** (it includes the new Minnesota office), which will not match until those pages are updated.
3. Founding year: this page says 2004 (per the IBTimes profile and Steven's records). A directory listing was told October 2024. Keep them consistent.
4. Replace the GitHub personal access token that was shared during the build.
