# Linking strategy: /resources/choosing-an-ethical-collection-agency/

## Cluster position
Spoke in the "choosing and evaluating a collection agency" cluster. Supports the money page /industries/commercial-collections/ and sits beside the existing how-to-hire post. Differentiated angle: why the industry's reputation is bad and what ethical conduct looks like. The existing post covers fee structure, process and success-rate questions.

## Outbound internal links already in the page (all returned 200 on 2026-10-03; re-verify before publish)
- /industries/commercial-collections/ (money page)
- /industries/commercial-collections/b2b-collections/
- /resources/collection-process/
- /resources/blog/how-to-hire-a-collection-agency-tips-for-businesses
- /resources/blog/how-does-a-debt-collection-agency-work-process-costs-explained
- /resources/blog/how-to-collect-unpaid-invoices-from-businesses-commercial-collections-explained
- /request-a-quote/ (conversion page; CTA button, with ?utm_source=agency-guide)

## External links (authoritative sources, all returned 200)
- GovInfo: Fair Debt Collection Practices Act findings and purpose
- FTC: 21st Annual Report to Congress on the FDCPA
- Congressional Research Service: FDCPA overview (enactment date)
- International Business Times, Jan 27 2026 (contributor content)
These are normal followed links; no nofollow needed for government and reference sources. The IBTimes link may be left as-is.

## Inbound links to add within 7 days of publish
1. /resources/blog/how-to-hire-a-collection-agency-tips-for-businesses: one sentence near the top, anchor "why collection agencies have a bad reputation".
2. /industries/commercial-collections/: add to the Related Services and Guides box, anchor "How to Choose an Ethical Collection Agency".
3. /resources/blog/how-does-a-debt-collection-agency-work-process-costs-explained: in the section about choosing an ethical agency, anchor "ten questions to ask a collection agency".
4. /resources/ hub (if it lists guides): add a card.

## Anchor rules
- Exact-match "ethical debt collection agency" at most once site-wide, and only if it reads naturally. Prefer descriptive and branded anchors.
- Do not touch URL-frozen assets (/resources/best-collection-agency/ and all /about/locations/[city]/ pages) except one in-body text link where a sentence naturally supports it.

## Cannibalization watch
Compare Search Console queries for this page against the how-to-hire post after 30 days. If they split the same queries, escalate to Steven; do not merge or redirect without his approval.
